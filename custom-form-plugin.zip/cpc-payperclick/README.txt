// installation
1. download the zip file or use git to clone the project.
2. unzip and save it in the htdocs/root directory of xampp server or website server.

3. Then create a database named clicks and import in phpmyadmin clicks.sql of the cpc-payperclick/click directory

Then  run the cpc-payperclick folder

//Database interaction
incase of editing remember to edit click/connect.php


//Technology used
CPC website pay per add click. php & mysql 

//features
each castomer has his own dashboard and can click ad id once in a day and earnings accumulate.
Admin dashboard.
manual withdrawal.
refferals.
well organised dashboard.

    <!-- Add common footer content here -->
    <!-- Example: -->
    <footer style="background-color: #000; color: #fff; text-align: center; padding: 10px;">
        <p>&copy; <?php echo date("Y"); ?> Your Website Name. All rights reserved.</p>
    </footer>
</body>
</html>

 PHP CPC Website Installation Guide

Thank you for choosing our CPC Website! Follow the instructions below to set up the system on your server.

## Prerequisites

- Web server (e.g., Apache, Nginx)
- PHP (version 7.0 or later)
- MySQL database
- Composer (for managing PHP dependencies)

## Installation Steps

 unzip and upload the folder to loot directory to your website or xampp
##open the folder and check click.sql database file and import it on phpmyadmin

##then load. www.url.com/click    url.com edit to your own website link

## on local host load http://localhost/click